from django.shortcuts import render


from fileupload.models import UploadedCSV
from fileupload.models import UploadedData
# from .models import UploadedData
# from django.shortcuts import render, get_object_or_404
# import os
# from django.conf import settings



def project(request):
    # return render(request, 'project.html')

# def display_csv_data(request):
    csv_data = UploadedData.objects.all()  # Retrieve all CSV data from the database
    return render(request, 'project.html', {'csv_data': csv_data})

# prodejec section
# views.py
# def predict(request,file_id):
#     uploaded_csv = UploadedCSV.objects.get(id=file_id)
#     file_name = uploaded_csv.file.name  # Retrieve file name from database
#     file_path = settings.MEDIA_URL + file_name  # Construct file path from media folder
#     return render(request, 'predict.html', {'file_path': file_path})

# def predict(request, file_id):
#     file_record = get_object_or_404(UploadedCSV, pk=file_id)
#     file_path = os.path.join(settings.MEDIA_ROOT, str(file_record.file))
#     return render(request, 'predict.html', {'file_path': file_path})
