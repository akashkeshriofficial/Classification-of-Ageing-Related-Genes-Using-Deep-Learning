# models.py

from django.db import models

class UploadedData(models.Model):
    csv_file = models.FileField(upload_to='media/')
    username = models.CharField(max_length=100)
    uploaded_at = models.DateTimeField(auto_now_add=True)

class UploadedCSV(models.Model):
    file = models.FileField(upload_to='media/')
    # target_v=models.CharField(max_length=100)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.file.name
    

# models UploadedData


