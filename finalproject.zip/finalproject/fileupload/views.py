# views.py

from django.shortcuts import render,redirect
# from .models import UploadedCSV
from django.conf import settings
import os
# from django.shortcuts import render, redirect
from .models import UploadedData
from .forms import UploadedDataForm

def uploadform(request):
    return render(request, 'form.html')


# def upload_csv(request):
#     if request.method == 'POST' and request.FILES['csv_file']:
#         csv_file = request.FILES['csv_file']
#         # Save the file to the media folder
#         with open(os.path.join(settings.MEDIA_ROOT, csv_file.name), 'wb+') as destination:
#             for chunk in csv_file.chunks():
#                 destination.write(chunk)
#         # Save the file details to the database
#         uploaded_csv = UploadedCSV(file=csv_file.name)
#         uploaded_csv.save()
#         return redirect('project')
#         # return render(request, 'project.html', {'message': 'File uploaded successfully!'})
#     return redirect('project')
#     # return render(request, 'project.html')

def upload_data(request):
    if request.method == 'POST':
        form = UploadedDataForm(request.POST, request.FILES)

        csv_file = request.FILES['csv_file']
        username = request.POST['username']
        # Save the file to the media folder
        with open(os.path.join(settings.MEDIA_ROOT, csv_file.name), 'wb+') as destination:
            for chunk in csv_file.chunks():
                destination.write(chunk)
        form = UploadedData(csv_file=csv_file.name,username=username)

        # if form.is_valid():
        form.save()
        return redirect('project')  # Redirect to a success page
    else:
        form = UploadedDataForm()
    return render(request, 'project.html', {'form': form})