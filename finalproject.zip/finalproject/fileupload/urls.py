# urls.py

from django.urls import path
from . import views
from django.shortcuts import render, redirect
from django.conf import settings
from django.conf.urls.static import static
from .forms import UploadedDataForm

urlpatterns =[
    path('', views.uploadform, name="fileupload"),
    # path('upload/', views.upload_csv, name='upload_csv'),
    path('upload/', views.upload_data, name='upload_data'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# views.py

# def upload_data(request):
#     if request.method == 'POST':
#         form = UploadedDataForm(request.POST, request.FILES)
#         if form.is_valid():
#             form.save()
#             return redirect('success_page')  # Redirect to a success page
#     else:
#         form = UploadedDataForm()
#     return render(request, 'form.html', {'form': form})


# views.py

