# urls.py

from django.urls import path
from . import views
# /from .models import UploadedCSV
from django.conf import settings
from django.conf.urls.static import static

urlpatterns =[
    # path('', views.project, name='project'),
    path('<int:id>', views.prediction, name='prediction'),
   
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
