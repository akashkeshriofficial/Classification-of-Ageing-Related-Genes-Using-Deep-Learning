from django.shortcuts import render
# from fileupload.models import UploadedCSV
from fileupload.models import UploadedData
# from django.shortcuts import render, get_object_or_404
import os
from django.conf import settings

from django.shortcuts import render
from sklearn.metrics import roc_curve, roc_auc_score, accuracy_score, confusion_matrix
import pandas as pd
from sklearn.metrics import roc_curve
from sklearn.metrics import confusion_matrix
# from keras.models import Sequential
from keras.models import load_model
import numpy as np


def prediction(request, id):
    uploaded_csv = UploadedData.objects.get(id=id)
    file_name = uploaded_csv.csv_file.name  # Retrieve file name from database
    tagert_v = uploaded_csv.username # Retrieve file name from database
    # file_path = settings.MEDIA_URL # Construct file path from media folder
    # file_path = settings.MEDIA_URL + file_name  # Construct file path from media folder
    # file_path='media'
    
    data = pd.read_csv('media'+'/'+ file_name)
  
    # Preprocess data
    X = data.drop(columns=[tagert_v])  # Assuming 'target_column' is the column to predict
    y = data[tagert_v]
    
    # Load model
    model = load_model('prediction\model.h5')
    
    # Make predictions
    predictions = model.predict(X)
    
    # Calculate ROC curve
    fpr, tpr, _ = roc_curve(y, predictions)
    
    # Calculate ROC AUC score
    roc_auc = roc_auc_score(y, predictions)
    
    # Calculate accuracy
    acc = accuracy_score(y, np.round(predictions))
    
    # Calculate confusion matrix
    cm = confusion_matrix(y, np.round(predictions))
    
    return render(request, 'predict.html', {'fpr': fpr.tolist(), 'tpr': tpr.tolist(), 'roc_auc': roc_auc, 'accuracy': acc, 'confusion_matrix': cm.tolist(),'tagert_v':tagert_v})
   
   
   
    # return render(request,'predict.html', {'file_path': file_path})

