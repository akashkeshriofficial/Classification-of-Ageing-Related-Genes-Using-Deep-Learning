"""
URL configuration for finalproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
# urls.py
from . import views
# /from .models import UploadedCSV
from django.conf import settings
from django.conf.urls.static import static
# from .django index

urlpatterns = [
    path('admin/', admin.site.urls),
    # path('',index.home,name='home')



    path('',views.home,name="home"),
    # path('project-details/',views.projectdetail),
    path('fileupload/', include('fileupload.urls'),name="fileupload"),
    path('project/', include('project.urls'),name="project"),
    path('prediction/', include('prediction.urls'),name="prediction"),
    path('about/', views.about,name="about"),
    path('projectdetails/', views.projectdetails,name="projectdetails"),

]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)