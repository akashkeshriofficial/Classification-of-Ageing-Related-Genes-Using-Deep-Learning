from django.shortcuts import render,redirect
from django.conf import settings
import os

def home(request):
    return render(request, 'index.html')

def projectdetails(request):
    return render(request, 'pdetail.html')

def about(request):
    return render(request, 'about.html')